<?php
    
    $koneksi = mysqli_connect("localhost","root","","dbkepolisian");

    include "fpdf.php";
  

    $no_lapkejadian=$_GET['id'];
    //select regular
    $query = mysqli_query($koneksi, "SELECT * from laporan 
    JOIN detailpenduduk ON laporan.no_lapkejadian=detailpenduduk.no_lapkejadian 
    JOIN penduduk ON detailpenduduk.nik=penduduk.nik 
    JOIN detailstatus ON penduduk.nik=detailstatus.nik 
    JOIN status_penduduk ON detailstatus.id_status=status_penduduk.id_status 
    join detail_kejahatan on laporan.no_lapkejadian=detail_kejahatan.no_lapkejadian 
    join kejahatan on detail_kejahatan.id_kejahatan=kejahatan.id_kejahatan 
    join detail_pasal on kejahatan.id_kejahatan=detail_pasal.id_kejahatan 
    join pasal on detail_pasal.id_pasal=pasal.id_pasal 
    join detail_penyidik on laporan.no_lapkejadian=detail_penyidik.no_lapkejadian 
    join petugaskepolisian on detail_penyidik.nrp=petugaskepolisian.nrp where laporan.no_lapkejadian='$no_lapkejadian'" );
    $data = mysqli_fetch_assoc($query);


    //pelapor
    $pelapor = mysqli_query($koneksi, "SELECT * from laporan 
    JOIN detailpenduduk ON laporan.no_lapkejadian=detailpenduduk.no_lapkejadian 
    JOIN penduduk ON detailpenduduk.nik=penduduk.nik 
    JOIN detailstatus ON penduduk.nik=detailstatus.nik 
    JOIN status_penduduk ON detailstatus.id_status=status_penduduk.id_status 
    join detail_kejahatan on laporan.no_lapkejadian=detail_kejahatan.no_lapkejadian 
    join kejahatan on detail_kejahatan.id_kejahatan=kejahatan.id_kejahatan 
    join detail_pasal on kejahatan.id_kejahatan=detail_pasal.id_kejahatan 
    join pasal on detail_pasal.id_pasal=pasal.id_pasal where laporan.no_lapkejadian='$no_lapkejadian' and detailstatus.id_status='S01'" );
    $ambilpelapor = mysqli_fetch_assoc($pelapor); 

    //saksi
    $saksi = mysqli_query($koneksi, "SELECT * from laporan 
    JOIN detailpenduduk ON laporan.no_lapkejadian=detailpenduduk.no_lapkejadian 
    JOIN penduduk ON detailpenduduk.nik=penduduk.nik 
    JOIN detailstatus ON penduduk.nik=detailstatus.nik 
    JOIN status_penduduk ON detailstatus.id_status=status_penduduk.id_status 
    join detail_kejahatan on laporan.no_lapkejadian=detail_kejahatan.no_lapkejadian 
    join kejahatan on detail_kejahatan.id_kejahatan=kejahatan.id_kejahatan 
    join detail_pasal on kejahatan.id_kejahatan=detail_pasal.id_kejahatan 
    join pasal on detail_pasal.id_pasal=pasal.id_pasal where laporan.no_lapkejadian='$no_lapkejadian' and detailstatus.id_status='S03'" );
    $ambilsaksi = mysqli_fetch_assoc($saksi); 


    //tersangka
    $terlapor = mysqli_query($koneksi, "SELECT * from laporan 
    JOIN detailpenduduk ON laporan.no_lapkejadian=detailpenduduk.no_lapkejadian 
    JOIN penduduk ON detailpenduduk.nik=penduduk.nik 
    JOIN detailstatus ON penduduk.nik=detailstatus.nik 
    JOIN status_penduduk ON detailstatus.id_status=status_penduduk.id_status 
    join detail_kejahatan on laporan.no_lapkejadian=detail_kejahatan.no_lapkejadian 
    join kejahatan on detail_kejahatan.id_kejahatan=kejahatan.id_kejahatan 
    join detail_pasal on kejahatan.id_kejahatan=detail_pasal.id_kejahatan 
    join pasal on detail_pasal.id_pasal=pasal.id_pasal
     where laporan.no_lapkejadian='$no_lapkejadian' and detailstatus.id_status='S04'" );
    $ambilterlapor = mysqli_fetch_assoc($terlapor); 


    $pdf = new FPDF ();
    $pdf -> AddPage();
    
    // $pdf -> Cell (200,10,'shopee.png','0','1','C', false); 



    $pdf -> SetFont ('Arial','B',12);
    $pdf -> Cell (200,10,'Laporan Polisi','0','1','C', false); 
    $pdf -> SetFont ('Arial','I',12);
    $pdf -> Cell (200,5,$data['no_lapkejadian'],'0','1','C', false); 


 //pelapor  
    $pdf -> SetFont ('Arial','B',10);
    $pdf -> Cell (200,10,'Pelapor','0','1','L', false); 


    $pdf -> SetFont ('Arial','',10);
    $pdf -> Cell (40,10,'Nama Pelapor     :','0','0','L', false); 
    $pdf -> Cell (10,10,$ambilpelapor['nama'],'0','1','C', false);

    $pdf -> SetFont ('Arial','',10);
    $pdf -> Cell (40,10,'NIK                       :','0','0','L', false); 
    $pdf -> Cell (10,10,$ambilpelapor['nik'],'0','1','C', false);

    $pdf -> SetFont ('Arial','',10);
    $pdf -> Cell (40,10,'Jenis Kelamin      :','0','0','L', false); 
    $pdf -> Cell (10,10,$ambilpelapor['jk'],'0','1','C', false);

    $pdf -> SetFont ('Arial','',10);
    $pdf -> Cell (68,10,'Alamat                 :','0','0','L', false); 
    $pdf -> Cell (10,10,'     '.$ambilpelapor['alamat'],'0','1','C', false);

    $pdf -> SetFont ('Arial','',10);
    $pdf -> Cell (40,10,'No.Telepon          :','0','0','L', false); 
    $pdf -> Cell (10,10,$ambilpelapor['notlp'],'0','1','C', false);

//saksi
// $pdf -> SetFont ('Arial','B',10);
// $pdf -> Cell (200,10,'','0','1','L', false); 

$pdf -> SetFont ('Arial','B',10);
$pdf -> Cell (200,10,'Saksi','0','1','L', false); 


$pdf -> SetFont ('Arial','',10);
$pdf -> Cell (40,10,'Nama saksi         :','0','0','L', false); 
$pdf -> Cell (10,10,$ambilsaksi['nama'],'0','1','C', false);

$pdf -> SetFont ('Arial','',10);
$pdf -> Cell (40,10,'NIK                       :','0','0','L', false); 
$pdf -> Cell (10,10,$ambilsaksi['nik'],'0','1','C', false);

$pdf -> SetFont ('Arial','',10);
$pdf -> Cell (40,10,'Jenis Kelamin      :','0','0','L', false); 
$pdf -> Cell (10,10,$ambilsaksi['jk'],'0','1','C', false);

$pdf -> SetFont ('Arial','',10);
$pdf -> Cell (45,10,'Alamat                 :','0','0','L', false); 
$pdf -> Cell (10,10,'     '.$ambilsaksi['alamat'],'0','1','C', false);

$pdf -> SetFont ('Arial','',10);
$pdf -> Cell (40,10,'No.Telepon          :','0','0','L', false); 
$pdf -> Cell (10,10,$ambilsaksi['notlp'],'0','1','C', false);


//pelaku
// $pdf -> SetFont ('Arial','B',10);
// $pdf -> Cell (200,10,'','0','1','L', false); 

$pdf -> SetFont ('Arial','B',10);
$pdf -> Cell (200,10,'Pelaku','0','1','L', false); 


$pdf -> SetFont ('Arial','',10);
$pdf -> Cell (40,10,'Nama Pelaku      :','0','0','L', false); 
$pdf -> Cell (10,10,$ambilterlapor['nama'],'0','1','C', false);

$pdf -> SetFont ('Arial','',10);
$pdf -> Cell (40,10,'NIK                       :','0','0','L', false); 
$pdf -> Cell (10,10,$ambilterlapor['nik'],'0','1','C', false);

$pdf -> SetFont ('Arial','',10);
$pdf -> Cell (40,10,'Jenis Kelamin      :','0','0','L', false); 
$pdf -> Cell (10,10,$ambilterlapor['jk'],'0','1','C', false);

$pdf -> SetFont ('Arial','',10);
$pdf -> Cell (55,10,'Alamat                 :','0','0','L', false); 
$pdf -> Cell (10,10,'     '.$ambilterlapor['alamat'],'0','1','C', false);

$pdf -> SetFont ('Arial','',10);
$pdf -> Cell (40,10,'No.Telepon          :','0','0','L', false); 
$pdf -> Cell (10,10,$ambilterlapor['notlp'],'0','1','C', false);



//Peristiwa yang Dilaporkan
// $pdf -> SetFont ('Arial','B',10);
// $pdf -> Cell (200,10,'','0','1','L', false); 

$pdf -> SetFont ('Arial','B',10);
$pdf -> Cell (200,10,'Peristiwa yang Dilaporkan','0','1','L', false); 


$pdf -> SetFont ('Arial','',10);
$pdf -> Cell (40,10,'Tanggal Kejadian      :','0','0','L', false); 
$pdf -> Cell (10,10,$data['tgl_kejadian'],'0','1','C', false);

$pdf -> SetFont ('Arial','',10);
$pdf -> Cell (55,10,'Tempat Kejadian      :','0','0','L', false); 
$pdf -> Cell (10,10,$data['tempat_kejadian'],'0','1','C', false);

$pdf -> SetFont ('Arial','',10);
$pdf -> Cell (40,10,'Status Kejadian      :','0','0','L', false); 
$pdf -> Cell (10,10,$data['status_kejadian'],'0','1','C', false);

$pdf -> SetFont ('Arial','',10);
$pdf -> Cell (55,10,'Kejahatan              :','0','0','L', false); 
$pdf -> Cell (30,10,'     '.$data['nama_kejahatan'],'0','1','C', false);

$pdf -> SetFont ('Arial','',10);
$pdf -> Cell (60,10,'Pasal Terkait         :','0','0','L', false); 
$pdf -> Cell (25,10,$data['pasal'],'0','0','C', false);
$pdf -> SetFont ('Arial','B',10);
$pdf -> Cell (150,10,'Penyidik','0','1','C', false);


//Penyidik
$pdf -> SetFont ('Arial','',10);
$pdf -> Cell (320,10,$data['nama'].'  ['.$data['nrp'].']','0','0','C', false); 


    $pdf -> Output();
?>