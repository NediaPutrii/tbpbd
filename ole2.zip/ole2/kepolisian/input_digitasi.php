<!DOCTYPE html>
<html>
    <head>
        <title>Leaflet.draw drawing and editing tools</title>

        <link rel="stylesheet" href="leaflet/leaflet.css" />
        <!--[if lte IE 8]><link rel="stylesheet" href="leaflet/leaflet.ie.css" /><![endif]-->
        <link rel="stylesheet" href="leaflet/plugins/leaflet-draw/dist/leaflet.draw.css" />
        <!--[if lte IE 8]><link rel="stylesheet" href="leaflet/plugins/leaflet-draw/dist/leaflet.draw.ie.css" /><![endif]-->

        <script src="leaflet/leaflet.js"></script>
		<script src="assets/plugins/jquery/js/jquery-1.10.1.min.js"></script>
        <script src="leaflet/plugins/leaflet-draw/src/Leaflet.draw.js"></script>

        <script src="leaflet/plugins/leaflet-draw/src/edit/handler/Edit.Poly.js"></script>
        <script src="leaflet/plugins/leaflet-draw/src/edit/handler/Edit.SimpleShape.js"></script>
        <script src="leaflet/plugins/leaflet-draw/src/edit/handler/Edit.Circle.js"></script>
        <script src="leaflet/plugins/leaflet-draw/src/edit/handler/Edit.Rectangle.js"></script>

        <script src="leaflet/plugins/leaflet-draw/src/draw/handler/Draw.Feature.js"></script>
        <script src="leaflet/plugins/leaflet-draw/src/draw/handler/Draw.Polyline.js"></script>
        <script src="leaflet/plugins/leaflet-draw/src/draw/handler/Draw.Polygon.js"></script>
        <script src="leaflet/plugins/leaflet-draw/src/draw/handler/Draw.SimpleShape.js"></script>
        <script src="leaflet/plugins/leaflet-draw/src/draw/handler/Draw.Rectangle.js"></script>
        <script src="leaflet/plugins/leaflet-draw/src/draw/handler/Draw.Circle.js"></script>
        <script src="leaflet/plugins/leaflet-draw/src/draw/handler/Draw.Marker.js"></script>

        <script src="leaflet/plugins/leaflet-draw/src/ext/LatLngUtil.js"></script>
        <script src="leaflet/plugins/leaflet-draw/src/ext/PolygonUtil.js"></script>
        <script src="leaflet/plugins/leaflet-draw/src/ext/LineUtil.Intersect.js"></script>
        <script src="leaflet/plugins/leaflet-draw/src/ext/Polyline.Intersect.js"></script>
        <script src="leaflet/plugins/leaflet-draw/src/ext/Polygon.Intersect.js"></script>

        <script src="leaflet/plugins/leaflet-draw/src/Control.Draw.js"></script>
        <script src="leaflet/plugins/leaflet-draw/src/Tooltip.js"></script>
        <script src="leaflet/plugins/leaflet-draw/src/Toolbar.js"></script>

        <script src="leaflet/plugins/leaflet-draw/src/draw/DrawToolbar.js"></script>
        <script src="leaflet/plugins/leaflet-draw/src/edit/EditToolbar.js"></script>
        <script src="leaflet/plugins/leaflet-draw/src/edit/handler/EditToolbar.Edit.js"></script>
        <script src="leaflet/plugins/leaflet-draw/src/edit/handler/EditToolbar.Delete.js"></script>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.8.0/css/bulma.min.css">
        <script defer src="https://use.fontawesome.com/releases/v5.3.1/js/all.js"></script>
        <style>
        .form
        {
            weight : 400px;
        }
    </style>
    </head>
    

	
	
<!--	
	<form name="form1" action="#" method="post" onSubmit="return validasi()">
    <table width="800" border="0" align="center" cellpadding="0" cellspacing="2" bordercolor="#6f0084">
		<tr>
			<td width="250" align="right" cellpadding="2">nama penyulang</td>
			<td width="236"><input type="text" name="nama"></td>
		
		
			<td width="127" align="right">koordinat</td>
			<td width="236"><input type="text" name="poligon"></td>
		
			
			
			<td width="250">
			<center>
			<input type="submit" name="Submit" value="kirim">
            <input type="reset" name="Submit2" value="reset">
			</center></td>
  </tr>
</table>


</form>
-->
<body>
        <div id="map" style="width: 100%; height:560px; border: 1px solid #ccc"></div>
        <!--<button id="changeColor">Rectangle -> Blue</button>-->
        <script>
            function toWKT(layer) {
                var lng, lat, coords = [];
                if (layer instanceof L.Polygon || layer instanceof L.Polyline) {
                    var latlngs = layer.getLatLngs();
                    for (var i = 0; i < latlngs.length; i++) {
                        latlngs[i]
                        coords.push(latlngs[i].lng + " " + latlngs[i].lat);
                        if (i === 0) {
                            lng = latlngs[i].lng;
                            lat = latlngs[i].lat;
                        }
                    };
                    if (layer instanceof L.Polygon) {
                        return "POLYGON((" + coords.join(",") + "," + lng + " " + lat + "))";
						
                    } else if (layer instanceof L.Polyline) {
                        return "LINESTRING(" + coords.join(",") + ")";
                    }
                } else if (layer instanceof L.Marker) {
                    return "POINT(" + layer.getLatLng().lng + " " + layer.getLatLng().lat + ")";
                }
				
            }
                
				
				var area = new L.LayerGroup();//file manggil poligon
				$.getJSON('gd_area_coba.php',function(data){
                    var geojsonLayer = new L.GeoJSON(data, {
                     }).addTo(area);
                });
				
				
            var cmAttr = 'Map data &copy; 2011 OpenStreetMap contributors, Imagery &copy; 2011 ESRI',
                OpenStreetURL = 'http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';
                EsriURL = 'http://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}';
                EsriWorldImageURL = 'http://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}';
                MapQuestURL = 'http://otile{s}.mqcdn.com/tiles/1.0.0/map/{z}/{x}/{y}.jpeg';
                
                var OpenStreet   = L.tileLayer(OpenStreetURL,{attribution: cmAttr}),
                ESRI  = L.tileLayer(EsriURL,{attribution: cmAttr}),
                ESRIWorldImage = L.tileLayer(EsriWorldImageURL,{attribution: cmAttr});

                var baseLayers = {
                    "OpenStreet": OpenStreet,
                    "ESRI": ESRI,
                    "ESRI World Image":ESRIWorldImage
                };
				
				
				var overlays = {
					"Area": area
                };
			var map = L.map('map', {
                    center: [0.5356302, 101.4391664],
                    zoom: 10,
                    layers: [OpenStreet]
                });
                L.control.layers(baseLayers,overlays).addTo(map);          
                L.control.scale().addTo(map);
				
            //taruh sini
			
			
			//sampe sini

            var drawnItems = new L.FeatureGroup();
            map.addLayer(drawnItems);

            var drawControl = new L.Control.Draw({
                draw: {
                    position: 'topleft',
                    polygon: {
                        title: 'Draw a sexy polygon!',
                        allowIntersection: false,
                        showArea: true,
                        drawError: {
                            color: '#b00b00',
                            timeout: 1000
                        },
                        shapeOptions: {
                            color: '#bada55'
                        }
                    },
                    circle: {
                        shapeOptions: {
                            color: '#662d91'
                        }
                    }
                },
                edit: {
                    featureGroup: drawnItems
                }
            });
            map.addControl(drawControl);

            map.on('draw:created', function (e) {
                var type = e.layerType,
                layer = e.layer;

                if (type === 'marker') {
                    layer.bindPopup('A popup!');
                }
                        
                if (type === 'polygon') {
                    layer.bindPopup(layer.getLatLngs());
					
                }
				//window.open("","MsgWindow","width=800,height=600");
               //alert(toWKT(layer));
				var nilai = prompt("Koordinat",toWKT(layer));
                var nilai = toWKT(layer);
				window.open("anak.php?nilai="+nilai+"&nolaporan=<?php echo $_GET['nolaporan']; ?>","Ratting","width=500,height=200,0,status=0,"); 
                drawnItems.addLayer(layer);
            });

            map.on('draw:edited', function (e) {
                var layers = e.layers;
                var countOfEditedLayers = 0;
                layers.eachLayer(function(layer) {
                    countOfEditedLayers++;
                    //layer.bindPopup(layer.getLatLngs());
                    alert(toWKT(layer));//.getLatLngs());
					
                });
                //  alert("Edited " + countOfEditedLayers + " layers");
                //console.log("Edited " + countOfEditedLayers + " layers");
            });

            L.DomUtil.get('changeColor').onclick = function () {
                drawControl.setDrawingOptions({ rectangle: { shapeOptions: { color: '#004a80' } } });

		   };
        </script>


</body>
		
</html>