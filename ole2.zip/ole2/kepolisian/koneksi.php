<?php

    $koneksi = mysqli_connect("localhost","root","","dbkepolisiann");
    if ($koneksi)
    {
        echo "BERHASIL";
    }else
    {
        echo "GAGAL";
    }


?>

