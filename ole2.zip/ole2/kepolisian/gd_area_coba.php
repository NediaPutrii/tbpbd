<?php
include('koneksi.php');
include_once('assets/plugins/geophp/Geophp.php');

$q = mysqli_query($koneksi,"SELECT astext(SHAPE),ID from tb_poli");
$i = 0;
while ($r = mysqli_fetch_array($q)) {
    $point = geoPHP::load($r[0], 'wkt');
    if ($i == 0) {
        $geojson = '{"type":"FeatureCollection","features":[{"type":"Feature","properties":{"id":"' . $r[1] . '"},"geometry":' . $point->out('json') . '},';
    } else {
        $geojson = $geojson . '{"type": "Feature","properties": { "id":"' . $r[1] . '"}, "geometry": ' . $point->out('json') . '},';
    }
    $i++;
}
$geojson = substr($geojson, 0, strlen($geojson) - 1);
$geojson = $geojson . ']}';
printf($geojson);
?>