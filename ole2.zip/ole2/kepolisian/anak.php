<?php 
include_once('koneksi.php');
?>


<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>

    <!-- Bootstrap -->
    <link href="dist/css/bootstrap.min.css" rel="stylesheet">

  
  </head>
  <body> 

<form name="form1" action="anak-p.php" method="post" >
    <table width="400" border="0" align="left" cellpadding="4" cellspacing="2" bordercolor="#6f0084">
		
		
		
		<!-- <tr>
			<td width="30" align="right" cellpadding="2"><label>Nama Daerah : </label></td>
			<td width="50"><input class="form-control" type="text" name="nama"></td>
		</tr>
		 -->
		
		 <tr>
			<td width="30" align="right"><label type="hidden" ></label></td>
			<td width="50"><input class="form-control" type="hidden"  name="nolaporan" value="<?php echo $_GET['nolaporan']; ?>"></td>
		</tr>

		<tr>
			<td width="30" align="right"><label>koordinat : </label></td>
			<td width="50"><input class="form-control" type="text" name="polygon" value="<?php echo $_GET['nilai']; ?>"></td>
		</tr>
		<tr>	
		<td></td>	
			<td >
			
			<button type="submit" class="btn btn-primary">simpan</button>
			<button type="reset" class="btn btn-primary">reset</button>
			</td>
  </tr>
</table>


</form>
</body>