CREATE TABLE `create` (
  `ID` int(11) NOT NULL auto_increment,
  `nama` varchar(20) NOT NULL,
  `SHAPE` geometry NOT NULL,
  `koordinat` text NOT NULL,
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `ID` (`ID`)
) ;