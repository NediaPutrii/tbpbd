<?php 
    $koneksi = mysqli_connect("localhost","root","","dbkepolisian");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.6.0/dist/leaflet.css"
   integrity="sha512-xwE/Az9zrjBIphAcBb3F6JVqxf46+CDLwfLMHloNu6KEQCAWi6HcDUbeOfBIptF7tcCzusKFjFw2yuvEpDL9wQ=="
   crossorigin=""/>
   
   <style type="text/css">
        #mapid 
        { height: 100%; }
        
   </style>
    <title>Document</title>

</head>


<body>

    <div id="mapid">



 <!-- Make sure you put this AFTER Leaflet's CSS -->
 <script src="https://unpkg.com/leaflet@1.6.0/dist/leaflet.js"
   integrity="sha512-gZwIG9x3wUXg2hdXF6+rVkLF/0Vi9U8D2Ntg4Ga5I5BZpVkVxlJWbSQtXPSiUTtC0TjtGOmxa1AJPuV0CPthew=="
   crossorigin=""></script>

   <script src="assets/leaflet.ajax.js"></script>

   <script type="text/javascript">
        var mymap = L.map('mapid').setView([0.5356302, 101.4391664], 10);
        L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={accessToken}', 
        {
            attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
            maxZoom: 18,
            id: 'mapbox/streets-v11',
            tileSize: 512,
            zoomOffset: -1,
            accessToken: 'pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw'
        }).addTo(mymap);

        var myStyle = 
        {
            "color": "#ff7800",
            "weight": 5,
            "opacity": 0.65
        };
  
    function popUp(f,l){
    var out = [];
        if (f.properties)
        {
            for(key in f.properties){
                out.push(key+": "+f.properties[key]);
            }
            l.bindPopup(out.join("<br />"));
        }
    }
var jsonTest = new L.GeoJSON.AJAX(["assets/pekanbarugeo.geojson"],{onEachFeature:popUp, style: myStyle}).addTo(mymap);

<?php
  // query
  //$kejahatan = $_POST['kejahatan'];
  $ambil=mysqli_query($koneksi,"SELECT * FROM laporan ") ;
  
  
  $js = '';
  
  // looping script js ini sesuai dengan jumlah lokasi yang ada pada database
  while($row = mysqli_fetch_assoc($ambil)) {
      
    $js = 'L.marker(['.$row['latitude'].', '.$row['longitude'].']).addTo(mymap).bindPopup("<b>'.$row['no_lapkejadian'].'</b>");';
    echo $js;
  }
  
  // menampilkan script js hasil dari looping diatas
  
?>
   </script>

</div>
</body>
</html>
