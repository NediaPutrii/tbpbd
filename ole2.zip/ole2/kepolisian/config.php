<?php
// $hostname = "localhost";
// $user_db = "root";
// $pass_db = "";
// $database = "digi";

$koneksi = mysqli_connect("localhost","root","","digi");
if ($koneksi)
{
    echo "BERHASIL";
}else
{
    echo "GAGAL";
}

// $connect_mysql = mysqli_connect($hostname, $user_db, $pass_db);
// $cnnect_db = mysqli_select_db($connect_mysql,$database);
?>
