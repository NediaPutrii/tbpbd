<?php 
$koneksi = mysqli_connect("localhost","root","","dbkepolisian");
$id_kejahatan = $_GET['id'];
 mysqli_query($koneksi,"DELETE FROM detail_pasal WHERE id_kejahatan='$id_kejahatan'");

$cek=mysqli_query($koneksi,"DELETE FROM kejahatan WHERE id_kejahatan='$id_kejahatan'");
//mysqli_query($koneksi,"DELETE FROM jenis_kejahatan WHERE id_jeniskejahatan='$id_kejahatan'")or die(mysql_error());

 if ($cek)
 {
     echo "
        <script>
        alert('data berhasil dihapus');
        document.location.href = '../view/tampilkejahatan.php';
        </script>
      ";
 }else
 {
     echo "
        <script>
        alert('data gagal dihapus');
        document.location.href = '../view/tampilkejahatan.php';
        </script>
      ";
}
// header("location:../view/tampilkejahatan.php");
?>