<?php 
$koneksi = mysqli_connect("localhost","root","","dbkepolisian");
$id_pasal = $_GET['id'];
$cek=mysqli_query($koneksi,"DELETE FROM pasal WHERE id_pasal='$id_pasal'")or die(mysql_error());
 
if ($cek)
 {
     echo "
        <script>
        alert('data berhasil dihapus');
        document.location.href = '../view/tampilpasal.php';
        </script>
      ";
 }else
 {
     echo "
        <script>
        alert('data gagal dihapus');
        document.location.href = '../view/tampilpasal.php';
        </script>
      ";
}
?>