<!DOCTYPE html>
<html>
<head>
	<title>CETAK LAPORAN </title>
</head>
<body>

	<center>

		<h2>DATA LAPORAN KEPOLISIAN</h2>
		

	</center>


	<table border="1" style="width: 100%">
		<tr>
			<th width="1%">No</th>
			<th>No Laporan</th>
    		<th>Tempat Kejadian</th>
    		<th>Tanggal Kejadian</th>
    		<th>Pelaku</th>
    		<th>Pelapor</th>
    		
    		
			
		</tr>
		<?php

		include '../koneksi.php'; 
		$no = 1;
		$result = mysqli_query($conn,"select * from laporan");
		while($data = mysqli_fetch_array($result)){
		?>
		<tr>
			<td><?php echo $no++; ?></td>
			<td><?php echo $data['no_lapkejadian']; ?></td>
			<td><?php echo $data['tempat_kejadian']; ?></td>
			<td><?php echo $data['tgl_kejadian']; ?></td>
			<td><?php echo $data['penanganan']; ?></td>
			<td><?php echo $data['status_kejadian']; ?></td>
		</tr>
		<?php 
		}
		?>
	</table>

	<script>
		window.print();
	</script>

</body>
</html>