<?php 
  require '../model/fungsi.php';
  

  if ( isset($_POST["tambah"]) ) {
    if ( tambah1($_POST) > 0  ) {
          
      if (tambah6($_POST)>0) {

         if (tambah3($_POST)>0 ) {

         echo "
        <script>
        alert('data berhasil ditambahkan');
        document.location.href = '../view/tambahterlapor.php';
        </script>
      ";
        }
          }
            }else {
              echo "
              <script>
                alert('data gagal ditambahkan');
                document.location.href = '../view/tambahterlapor.php';
                </script>
              ";
            }
          }else if(isset($_POST["save"])){
            if ( tambah1($_POST) > 0  ) {
                  
              if (tambah6($_POST)>0) {

                 if (tambah3($_POST)>0 ) {

                 echo "
                <script>
                alert('data berhasil ditambahkan');
                document.location.href = '../view/tambahpenyidik.php';
                </script>
              ";
                }
                  }
                    }else {
                      echo "
                      <script>
                        alert('data gagal ditambahkan');
                        document.location.href = '../view/tambahterlapor.php';
                        </script>
                      ";
                    }
          }

?> 
 