
 <?php

include_once("../koneksi.php");

$id=$_GET['id'];
mysqli_query($conn,"DELETE FROM detail_penyidik where no_lapkejadian='$id'");
$cek=mysqli_query($conn,"DELETE FROM laporan where no_lapkejadian='$id'");
if ($cek)
 {
     echo "
        <script>
        alert('data berhasil dihapus');
        document.location.href = '../view/halamantampil.php';
        </script>
      ";
 }else
 {
     echo "
        <script>
        alert('data gagal dihapus');
        document.location.href = '../view/halamantampil.php';
        </script>
      ";
}

// echo "<meta http-equiv='refresh' content='1;url=../view/halamantampil.php'>";
?> 
