-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 12 Apr 2020 pada 12.18
-- Versi server: 10.1.35-MariaDB
-- Versi PHP: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbkepolisian`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(200) NOT NULL,
  `status_admin` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id_admin`, `username`, `password`, `status_admin`) VALUES
(1, '8888888', '$2y$10$rcZ7rRTzMB1639xRG5UXCuUyabzmZm2ff7AqAvGV6/CkGMcIUtDLK', 'Master '),
(7, 'admin', '$2y$10$D/fN86gnyTerzrPnzFbaseflvo5i/Od6cOcwyYm4UGccQvN9QA3BW', 'Admin');

-- --------------------------------------------------------

--
-- Struktur dari tabel `detailpenduduk`
--

CREATE TABLE `detailpenduduk` (
  `nik` varchar(20) NOT NULL,
  `no_lapkejadian` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `detailpenduduk`
--

INSERT INTO `detailpenduduk` (`nik`, `no_lapkejadian`) VALUES
('098743', 'd3247983274'),
('11', ' laporan/23'),
('110000001000', ' K003'),
('110000001000', ' laporan/23'),
('1212121221', 'laporan/10'),
('123321', ' laporan/23'),
('13', 'laporan/11'),
('133333333333331', ' laporan/10'),
('13750000000021', ' K003'),
('13750000032', ' K001'),
('1375111111111', ' K001'),
('1375111111111', ' K003'),
('1375222222222', ' K001'),
('1375222222222', ' K003'),
('13752909292929', ' K001'),
('13752909292929', ' K003'),
('137532909090', ' K001'),
('13829082390', ' K003'),
('14', 'laporan/11'),
('14001', 'laporan/12'),
('14002', 'laporan/12'),
('14003', 'laporan/12'),
('1401061000008', ' laporan/03'),
('15000002', 'laporan/13'),
('18000025', 'laporan/13'),
('18200001', 'laporan/13'),
('19', 'laporan/11'),
('21', 'laporan/11'),
('4232213141', ' laporan/07'),
('4322222', ' laporan/06'),
('565565656', ' laporan/05'),
('77777', 'laporan/08'),
('78', ' o72819'),
('90', '093248'),
('fwerg', 'd3247983274');

-- --------------------------------------------------------

--
-- Struktur dari tabel `detailstatus`
--

CREATE TABLE `detailstatus` (
  `id_detail` int(11) NOT NULL,
  `id_status` varchar(20) NOT NULL,
  `nik` varchar(20) NOT NULL,
  `kali-ke` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `detailstatus`
--

INSERT INTO `detailstatus` (`id_detail`, `id_status`, `nik`, `kali-ke`) VALUES
(1, 'S01', '1375222222222', 4),
(2, 'S01', '137532909090', 1),
(3, 'S03', '13752909292929', 1),
(4, 'S02', '1375111111111', 1),
(5, 'S01', '13750000032', 1),
(6, 'S01', '1375222222222', 2),
(7, 'S01', '1375222222222', 3),
(8, 'S01', '1375111111111', 2),
(9, 'S01', '13750000000021', 1),
(10, 'S03', '110000001000', 1),
(11, 'S01', '13752909292929', 2),
(12, 'S01', '13829082390', 1),
(13, 'S01', '110000001000', 2),
(14, 'S01', '00000000000', 1),
(15, 'S01', '13829082390', 2),
(16, 'S03', '11', 1),
(17, 'S03', '13', 1),
(18, 'S01', '14', 1),
(19, 'S04', '14001', 1),
(20, 'S03', '14002', 1),
(21, 'S01', '14003', 1),
(22, 'S04', '1401061000008', 1),
(23, 'S04', '15000002', 1),
(24, 'S01', '18000025', 1),
(25, 'S03', '18200001', 1),
(26, 'S02', '19', 1),
(27, 'S04', '21', 1),
(28, 'S01', '77777', 1),
(29, 'S01', '11', 2),
(30, 'S01', '11', 3),
(31, 'S03', '123321', 1),
(32, 'S02', '110000001000', 3);

-- --------------------------------------------------------

--
-- Struktur dari tabel `detail_admin`
--

CREATE TABLE `detail_admin` (
  `id` int(11) NOT NULL,
  `no_lapkejadian` varchar(11) NOT NULL,
  `tgl` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `detail_kejahatan`
--

CREATE TABLE `detail_kejahatan` (
  `id_kejahatan` varchar(20) NOT NULL,
  `no_lapkejadian` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `detail_kejahatan`
--

INSERT INTO `detail_kejahatan` (`id_kejahatan`, `no_lapkejadian`) VALUES
('k1', ' 44444444'),
('k1', ' laporan/03'),
('k1', ' laporan/05'),
('k1', ' laporan/06'),
('k1', ' laporan/23'),
('k1', '5243'),
('k1', 'laporan/11'),
('k2', ' laporan/04'),
('k2', 'laporan/02/'),
('k2', 'laporan/12'),
('k3', ' K001'),
('k5', ' K003'),
('k5', 'laporan/13');

-- --------------------------------------------------------

--
-- Struktur dari tabel `detail_pasal`
--

CREATE TABLE `detail_pasal` (
  `id_pasal` varchar(20) NOT NULL,
  `id_kejahatan` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `detail_pasal`
--

INSERT INTO `detail_pasal` (`id_pasal`, `id_kejahatan`) VALUES
('P1', 'k1'),
('P3', 'k3'),
('P4', 'k1'),
('P4', 'k4'),
('P4', 'k5'),
('P6', 'k2');

-- --------------------------------------------------------

--
-- Struktur dari tabel `detail_penyidik`
--

CREATE TABLE `detail_penyidik` (
  `nrp` varchar(20) NOT NULL,
  `no_lapkejadian` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `detail_penyidik`
--

INSERT INTO `detail_penyidik` (`nrp`, `no_lapkejadian`) VALUES
('8000094', ' K001'),
('8000094', ' K003'),
('8000094', ' laporan/23'),
('80083192', ' laporan/04'),
('80083192', ' o72819'),
('80083192', '093248'),
('80083192', 'd3247983274'),
('80083192', 'laporan/10'),
('80083192', 'laporan/11'),
('80989089', 'laporan/12'),
('80989089', 'laporan/13'),
('9999999', ' K001');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jenis_kejahatan`
--

CREATE TABLE `jenis_kejahatan` (
  `id_jeniskejahatan` varchar(20) NOT NULL,
  `jenis_kejahatan` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `jenis_kejahatan`
--

INSERT INTO `jenis_kejahatan` (`id_jeniskejahatan`, `jenis_kejahatan`) VALUES
('jk1', 'pidana');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kecamatan`
--

CREATE TABLE `kecamatan` (
  `id_kecamatan` varchar(11) NOT NULL,
  `kecamatan` varchar(20) NOT NULL,
  `polygon` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kecamatan`
--

INSERT INTO `kecamatan` (`id_kecamatan`, `kecamatan`, `polygon`) VALUES
('kc1', 'bukit raya', ''),
('kc2', 'pekanbaru kota', ''),
('kc3', 'lima puluh', ''),
('kc4', 'rumbai', ''),
('kc5', 'rumbai pesisir', ''),
('kc6', 'senapelan', ''),
('kc7', 'sukajadi', ''),
('kc8', 'tampan', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kejahatan`
--

CREATE TABLE `kejahatan` (
  `id_kejahatan` varchar(20) NOT NULL,
  `id_jeniskejahatan` varchar(20) NOT NULL,
  `nama_kejahatan` varchar(30) NOT NULL,
  `ketarangan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kejahatan`
--

INSERT INTO `kejahatan` (`id_kejahatan`, `id_jeniskejahatan`, `nama_kejahatan`, `ketarangan`) VALUES
('k1', 'jk1', 'curanmor', 'pencurian sepeda motor'),
('k2', 'jk1', 'pencurian', 'pencurian'),
('k4', 'jk1', 'pembunuhan disertai tindak pid', 'pembunuhan yang terjadi ketika telah melakuka'),
('k5', 'jk1', 'curas', 'pencurian disertai kekerasan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `laporan`
--

CREATE TABLE `laporan` (
  `no_lapkejadian` varchar(11) NOT NULL,
  `tempat_kejadian` text NOT NULL,
  `tgl_kejadian` date NOT NULL,
  `penanganan` text NOT NULL,
  `status_kejadian` text NOT NULL,
  `latitude` varchar(50) NOT NULL,
  `longitude` varchar(50) NOT NULL,
  `id_kecamatan` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `laporan`
--

INSERT INTO `laporan` (`no_lapkejadian`, `tempat_kejadian`, `tgl_kejadian`, `penanganan`, `status_kejadian`, `latitude`, `longitude`, `id_kecamatan`) VALUES
(' 44444444', 'rumah uya kuya yayaya', '3333-03-31', 'tangkap basah', 'Kasus On Progress', '-8.632494223686324', '117.05003547831323', 'kc1'),
(' K001', 'Jalanan', '2020-04-10', 'hahaha', 'Kasus Ditutup', '0.5033905116152878', '101.42071723937988', 'kc1'),
(' K003', 'jljjljlj', '2020-08-19', 'jkgikvh', 'Kasus On Progress', '-8.4369434587408', '116.34701617411223', 'kc2'),
(' laporan/01', 'Kosan yaya', '2020-03-25', 'Tangkap tangan', 'Kasus Ditutup', '0.5242036165837011', '101.44387006759642', 'kc4'),
(' laporan/03', 'sman 1 pekanbaru', '2020-03-04', 'tangkap basah', 'Kasus Selesai', '0.5248580481583471 ', '101.4441168308258', 'kc5'),
(' laporan/04', 'rt4', '2020-07-03', 'tangkap tangan', 'Kasus On Progress', '0.5255319230808012', '101.4487126019059', 'kc3'),
(' laporan/05', 'vmdlkfbn', '2020-08-03', 'jnj jk', 'Kasus On Progress', '0.49952827856197185', '101.41822814941406', 'kc2'),
(' laporan/06', 'heth', '2020-02-03', 'njsgf', 'Kasus On Progress', '0.49781092470110866', '101.48092183134548', 'kc1'),
(' laporan/07', 'rumah haji somad', '2020-03-05', 'nfcjern', 'Kasus On Progress', '0.49708813471438484', '101.40473588797545', 'kc6'),
(' laporan/09', 'cjhskdb v', '2020-04-05', 'vjsdwbf', 'Kasus On Progress', '0.5245040114133477', '101.44351601600647', 'kc6'),
(' laporan/10', 'di jalan banda aceh, samping bandar', '2020-04-06', 'tangkap tangan', 'Kasus On Progress', '0.5035619668086678', '101.47165095701594', 'kc8'),
(' laporan/23', 'Jl.Kemang', '2020-04-17', 'Dipukul masa', 'Kasus On Progress', '0.8129790828714628', '101.48096258184593', 'kc3'),
(' o72819', 'pdg panjang', '2020-03-03', 'ndskadn', 'Kasus On Progress', '-9.029554875263651', '116.69154357514229', 'kc1'),
('093248', 'pdg', '2020-03-12', 'isodaha', 'Kasus Ditutup', '-8.85048273798579', '116.42512511811104', 'kc4'),
('33333', 'frwef', '2020-03-22', 'vgetrh', 'in progres', '0.5242358017447037 ', '101.44515752792358', 'kc5'),
('5243', 'dqje', '2012-10-10', 'jfbkweir', 'Kasus On Progress', '-8.729152403478155', '116.57487678690698', 'kc6'),
('d3247983274', 'njewn`', '1020-01-10', 'djkewf`', 'Please Select', '-8.679197355167567', '116.09697151346948', 'kc2'),
('laporan/02/', 'fwerf', '2020-09-10', 'fwerf', 'Kasus On Progress', '-8.394001564431443', '115.59709358378198', 'kc7'),
('laporan/08', 'rumah haji sueb', '2020-09-05', 'tangkap tangan', 'on progress', '101.45028695691778', '0.5259465935500823', 'kc6'),
('laporan/10', 'Jl Banda aceh, sebelah indomaret', '2020-04-06', 'tangkap tangan', 'Kasus On Progress', '0.5031215017371135', '101.4716363325455', 'kc2'),
('laporan/11', 'Bundaran keris', '2020-09-15', 'tangkap tangan', 'On progres', '0.5253536078955505', '101.45265614656545', 'kc4'),
('laporan/12', 'Jl Pangeran Hidayat, gg, panger', '2020-02-12', 'tangkap tangan', 'on progress', '0.5242162884337509', '101.44547339006482', 'kc2'),
('laporan/13', 'Indomaret Jl. Pangeran Hidayat', '2019-05-19', 'Tangkap tangan', 'On progress', '0.5241607030354346', '101.44702434539795', 'kc2');

--
-- Trigger `laporan`
--
DELIMITER $$
CREATE TRIGGER `delete_laporan` BEFORE DELETE ON `laporan` FOR EACH ROW BEGIN INSERT INTO log (ket, datetime,user, data_lama) VALUES (CONCAT('Delete data ke tabel laporan, no_lapkejadian = ', old.no_lapkejadian),NOW(), USER(), old.no_lapkejadian);END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `insert_laporan` BEFORE INSERT ON `laporan` FOR EACH ROW BEGIN
  INSERT INTO log (ket,datetime, user, data_baru)
  VALUES (CONCAT('Insert data ke tabel laporan, no_lapkejadian = ', NEW.no_lapkejadian),NOW(), USER(), NEW.no_lapkejadian);END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `update_laporan` AFTER UPDATE ON `laporan` FOR EACH ROW BEGIN
  INSERT INTO log (ket, datetime,user, data_lama, data_baru)
  VALUES (CONCAT('Update data ke tabel laporan, no_lapkejadian = ', NEW.no_lapkejadian),NOW(), USER(), old.no_lapkejadian, NEW.no_lapkejadian);END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `log`
--

CREATE TABLE `log` (
  `ket` text NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user` varchar(50) NOT NULL DEFAULT '',
  `data_lama` varchar(25) NOT NULL DEFAULT '',
  `data_baru` varchar(25) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `log`
--

INSERT INTO `log` (`ket`, `datetime`, `user`, `data_lama`, `data_baru`) VALUES
('Insert data ke tabel laporan, no_lapkejadian = K004', '2020-04-11 07:30:29', 'root@localhost', '', 'K004'),
('Insert data ke tabel laporan, no_lapkejadian =  K005', '2020-04-11 07:31:35', 'root@localhost', '', ' K005'),
('Insert data ke tabel laporan, no_lapkejadian =  k00', '2020-04-11 07:36:27', 'root@localhost', '', ' k00'),
('Insert data ke tabel laporan, no_lapkejadian =  k002', '2020-04-11 07:37:07', 'root@localhost', '', ' k002'),
('Insert data ke tabel laporan, no_lapkejadian =  k008', '2020-04-11 07:38:15', 'root@localhost', '', ' k008'),
('Delete data ke tabel laporan, no_lapkejadian =  K001', '2020-04-11 14:50:36', 'root@localhost', ' K001', ''),
('Delete data ke tabel laporan, no_lapkejadian =  K003', '2020-04-11 14:50:45', 'root@localhost', ' K003', ''),
('Delete data ke tabel laporan, no_lapkejadian =  k00', '2020-04-11 14:53:53', 'root@localhost', ' k00', ''),
('Delete data ke tabel laporan, no_lapkejadian =  K003', '2020-04-11 14:53:58', 'root@localhost', ' K003', ''),
('Delete data ke tabel laporan, no_lapkejadian =  K003', '2020-04-11 14:57:04', 'root@localhost', ' K003', ''),
('Delete data ke tabel laporan, no_lapkejadian =  K003', '2020-04-11 15:02:26', 'root@localhost', ' K003', ''),
('Delete data ke tabel laporan, no_lapkejadian =  K003', '2020-04-11 15:02:31', 'root@localhost', ' K003', ''),
('Delete data ke tabel laporan, no_lapkejadian =  K001', '2020-04-11 15:02:39', 'root@localhost', ' K001', ''),
('Delete data ke tabel laporan, no_lapkejadian =  K001', '2020-04-11 15:13:15', 'root@localhost', ' K001', ''),
('Update data ke tabel laporan, no_lapkejadian =  K001', '2020-04-11 17:43:26', 'root@localhost', ' K001', ' K001'),
('Delete data ke tabel laporan, no_lapkejadian =  K002', '2020-04-12 03:11:06', 'root@localhost', ' K002', ''),
('Update data ke tabel laporan, no_lapkejadian =  K003', '2020-04-12 03:12:35', 'root@localhost', ' K003', ' K003'),
('Update data ke tabel laporan, no_lapkejadian =  K001', '2020-04-12 03:28:28', 'root@localhost', ' K001', ' K001'),
('Update data ke tabel laporan, no_lapkejadian =  K001', '2020-04-12 03:36:44', 'root@localhost', ' K001', ' K001'),
('Update data ke tabel laporan, no_lapkejadian =  K003', '2020-04-12 03:38:24', 'root@localhost', ' K003', ' K003'),
('Update data ke tabel laporan, no_lapkejadian =  K005', '2020-04-12 03:49:37', 'root@localhost', ' K005', ' K005'),
('Update data ke tabel laporan, no_lapkejadian =  k008', '2020-04-12 03:50:13', 'root@localhost', ' k008', ' k008'),
('Update data ke tabel laporan, no_lapkejadian = K004', '2020-04-12 03:50:32', 'root@localhost', 'K004', 'K004'),
('Insert data ke tabel laporan, no_lapkejadian =  44444444', '2020-04-12 04:37:50', 'root@localhost', '', ' 44444444'),
('Insert data ke tabel laporan, no_lapkejadian =  laporan/01', '2020-04-12 04:37:50', 'root@localhost', '', ' laporan/01'),
('Insert data ke tabel laporan, no_lapkejadian =  laporan/03', '2020-04-12 04:37:50', 'root@localhost', '', ' laporan/03'),
('Insert data ke tabel laporan, no_lapkejadian =  laporan/04', '2020-04-12 04:37:50', 'root@localhost', '', ' laporan/04'),
('Insert data ke tabel laporan, no_lapkejadian =  laporan/05', '2020-04-12 04:37:50', 'root@localhost', '', ' laporan/05'),
('Insert data ke tabel laporan, no_lapkejadian =  laporan/06', '2020-04-12 04:37:50', 'root@localhost', '', ' laporan/06'),
('Insert data ke tabel laporan, no_lapkejadian =  laporan/07', '2020-04-12 04:37:50', 'root@localhost', '', ' laporan/07'),
('Insert data ke tabel laporan, no_lapkejadian =  laporan/09', '2020-04-12 04:37:50', 'root@localhost', '', ' laporan/09'),
('Insert data ke tabel laporan, no_lapkejadian =  laporan/10', '2020-04-12 04:37:50', 'root@localhost', '', ' laporan/10'),
('Insert data ke tabel laporan, no_lapkejadian =  o72819', '2020-04-12 04:37:50', 'root@localhost', '', ' o72819'),
('Insert data ke tabel laporan, no_lapkejadian = 093248', '2020-04-12 04:37:50', 'root@localhost', '', '093248'),
('Insert data ke tabel laporan, no_lapkejadian = 33333', '2020-04-12 04:37:50', 'root@localhost', '', '33333'),
('Insert data ke tabel laporan, no_lapkejadian = 5243', '2020-04-12 04:37:50', 'root@localhost', '', '5243'),
('Insert data ke tabel laporan, no_lapkejadian = d3247983274', '2020-04-12 04:37:50', 'root@localhost', '', 'd3247983274'),
('Insert data ke tabel laporan, no_lapkejadian = laporan/02/', '2020-04-12 04:37:50', 'root@localhost', '', 'laporan/02/'),
('Insert data ke tabel laporan, no_lapkejadian = laporan/08', '2020-04-12 04:37:50', 'root@localhost', '', 'laporan/08'),
('Insert data ke tabel laporan, no_lapkejadian = laporan/10', '2020-04-12 04:37:50', 'root@localhost', '', 'laporan/10'),
('Insert data ke tabel laporan, no_lapkejadian = laporan/11', '2020-04-12 04:37:50', 'root@localhost', '', 'laporan/11'),
('Insert data ke tabel laporan, no_lapkejadian = laporan/12', '2020-04-12 04:37:50', 'root@localhost', '', 'laporan/12'),
('Insert data ke tabel laporan, no_lapkejadian = laporan/13', '2020-04-12 04:37:50', 'root@localhost', '', 'laporan/13'),
('Delete data ke tabel laporan, no_lapkejadian =  K005', '2020-04-12 07:08:08', 'root@localhost', ' K005', ''),
('Delete data ke tabel laporan, no_lapkejadian =  K005', '2020-04-12 07:08:13', 'root@localhost', ' K005', ''),
('Delete data ke tabel laporan, no_lapkejadian =  k008', '2020-04-12 07:08:38', 'root@localhost', ' k008', ''),
('Delete data ke tabel laporan, no_lapkejadian =  K003', '2020-04-12 07:09:15', 'root@localhost', ' K003', ''),
('Delete data ke tabel laporan, no_lapkejadian =  K003', '2020-04-12 07:09:19', 'root@localhost', ' K003', ''),
('Delete data ke tabel laporan, no_lapkejadian =  K003', '2020-04-12 07:09:47', 'root@localhost', ' K003', ''),
('Delete data ke tabel laporan, no_lapkejadian = K004', '2020-04-12 07:09:59', 'root@localhost', 'K004', ''),
('Delete data ke tabel laporan, no_lapkejadian =  K001', '2020-04-12 07:10:13', 'root@localhost', ' K001', ''),
('Delete data ke tabel laporan, no_lapkejadian =  K003', '2020-04-12 07:10:19', 'root@localhost', ' K003', ''),
('Delete data ke tabel laporan, no_lapkejadian =  K005', '2020-04-12 07:10:23', 'root@localhost', ' K005', ''),
('Delete data ke tabel laporan, no_lapkejadian =  44444444', '2020-04-12 07:10:30', 'root@localhost', ' 44444444', ''),
('Delete data ke tabel laporan, no_lapkejadian =  44444444', '2020-04-12 07:11:51', 'root@localhost', ' 44444444', ''),
('Update data ke tabel laporan, no_lapkejadian =  K003', '2020-04-12 07:20:07', 'root@localhost', ' K003', ' K003'),
('Delete data ke tabel laporan, no_lapkejadian =  K005', '2020-04-12 07:20:55', 'root@localhost', ' K005', ''),
('Delete data ke tabel laporan, no_lapkejadian =  K005', '2020-04-12 07:21:03', 'root@localhost', ' K005', ''),
('Delete data ke tabel laporan, no_lapkejadian =  K005', '2020-04-12 07:23:54', 'root@localhost', ' K005', ''),
('Delete data ke tabel laporan, no_lapkejadian =  K005', '2020-04-12 07:25:18', 'root@localhost', ' K005', ''),
('Insert data ke tabel laporan, no_lapkejadian =  laporan/22', '2020-04-12 07:34:30', 'root@localhost', '', ' laporan/22'),
('Delete data ke tabel laporan, no_lapkejadian =  laporan/22', '2020-04-12 07:35:24', 'root@localhost', ' laporan/22', ''),
('Insert data ke tabel laporan, no_lapkejadian =  laporan/23', '2020-04-12 07:38:39', 'root@localhost', '', ' laporan/23');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pasal`
--

CREATE TABLE `pasal` (
  `id_pasal` varchar(20) NOT NULL,
  `pasal` varchar(50) NOT NULL,
  `isi_pasal` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pasal`
--

INSERT INTO `pasal` (`id_pasal`, `pasal`, `isi_pasal`) VALUES
('', '', ''),
('P1', 'pasal 363(Curanmor)', 'Barangsiapa mengambil barang sesuatu, yang seluruhnya atau sebagian kepunyaan orang lain, dengan maksud untuk dimiliki secara melawan hukum, diancam karena pencurian, dengan pidana penjara paling lama lima tahun atau denda paling banyak enam puluh rupiah.'),
('P2', 'pasal 338(Pembunuhan)', 'Barangsiapa dengan sengaja merampas nyawa orang lain, diancam karena pembunuhan dengan pidana penjara paling lama lima belas tahun.'),
('P3', 'pasal 340(pembunuhan berencana)', 'Barang siapa sengaja dan dengan rencana lebih dahulu merampas nyawa orang lain, diancam dengan pidana mati atau pidana penjara seumur hidup atau selama waktu tertentu, paling lama 20 tahun'),
('P4', 'pasal 339(pembunuhan disertai tindakan pidana)', 'Pembunuhan yang diikuti, disertai atau didahului oleh suatu perbuatan pidana, yang dilakukan dengan maksud untuk mempersiapkan atau mempermudah pelaksanaannya, atau untuk melepaskan diri sendiri maupun peserta lainnya dari pidana dalam hal tertangkap tangan, ataupun untuk memastikan penguasaan barang yang diperolehnya secara melawan hukum, diancam dengan pidana penjara seumur hidup atau selama waktu tertentu, paling lama dua puluh tahun.'),
('P5', 'pasal 372(penggelapan)', 'Barang siapa dengan sengaja dan melawan hukum memiliki barang sesuatu yang seluruhnya atau sebagian adalah kepunyaan orang lain, tetapi yang ada dalam kekuasaannya bukan karena kejahatan diancam karena penggelapan, dengan pidana penjara paling lama empat tahun atau pidana denda paling banyak sembilan ratus rupiah'),
('P6', 'pasal 362(pencurian)', 'Barangsiapa mengambil barang sesuatu, yang seluruhnya atau sebagian kepunyaan orang lain, dengan maksud untuk dimiliki secara melawan hukum, diancam karena pencurian, dengan pidana penjara paling lama lima tahun atau denda paling banyak enam puluh rupiah'),
('P8', 'pasal 341(pembunuhan anak)', 'Seorang ibu yang karena takut akan ketahuan melahirkan anak pada saat anak dilahirkan atau tidak lama kemudian, dengan sengaja merampas nyawa anaknya, diancam karena membunuh anak sendiri, dengan pidana penjara paling lama tujuh tahun.'),
('P9', 'pasal 346(aborsi)', 'Seorang wanita yang sengaja menggugurkan atau mematikan kandungannya atau menyuruh orang lain untuk itu, diancam dengan pidana penjara paling lama empat tahun.');

-- --------------------------------------------------------

--
-- Struktur dari tabel `penduduk`
--

CREATE TABLE `penduduk` (
  `nik` varchar(20) NOT NULL,
  `nama` varchar(39) NOT NULL,
  `ttl` date NOT NULL,
  `alamat` text NOT NULL,
  `jk` varchar(11) NOT NULL,
  `notlp` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `penduduk`
--

INSERT INTO `penduduk` (`nik`, `nama`, `ttl`, `alamat`, `jk`, `notlp`) VALUES
('00000000000', '00000000', '0000-00-00', '', 'Laki-laki', ''),
('098743', 'nabilah putri', '1978-02-10', 'Jl Kassa Sudirman Square', 'Laki-laki', '324321'),
('10001200101', 'Udin', '1976-08-19', 'Jl Kereta Api', 'Laki-laki', '983123321'),
('11', 'Hanifah Melga', '2000-03-24', 'Jl Duyung', 'Laki-laki', '08756656675'),
('110000001000', 'Pin', '2000-04-22', 'jhjkjhk', 'Laki-laki', '08888888888'),
('11111111111111111111', '', '0000-00-00', '', 'Laki-laki', ''),
('111111144444444', 'Dinu', '1997-07-12', 'Jl Bangau', 'Laki-laki', '9734276'),
('1199918288181', 'Jamil', '1993-02-10', 'Jl Kasa', 'Laki-laki', '0824367571'),
('1212121221', 'siti ropeah', '1987-06-16', 'jl Kopi', 'Perempuan', '081237428468'),
('123321', 'nedia', '2000-01-10', 'hkb', 'Perempuan', '65876576'),
('124325677678', 'syai', '1999-09-27', 'Bukit barisan', 'Perempuan', '0814323222'),
('13', 'saa', '2020-03-09', 'pdg', 'Laki-laki', '08567567'),
('13131375', '', '0000-00-00', '', 'Laki-laki', ''),
('133333333333331', 'ucok', '1885-04-13', 'jl hang tuah', 'Laki-laki', '0822222211331'),
('137500000000', '', '0000-00-00', '', 'Laki-laki', ''),
('13750000000021', 'Soni', '2000-09-01', 'Jl.Durian Runtuh No.22', 'Laki-laki', '08378213209'),
('13750000001', '', '0000-00-00', '', 'Laki-laki', ''),
('13750000002', '', '0000-00-00', '', 'Laki-laki', ''),
('13750000003', '', '0000-00-00', '', 'Laki-laki', ''),
('13750000032', 'Kaze', '2000-04-25', 'Jl. Bunga Citra Lestari', 'Laki-laki', '089090990'),
('1375000004', '', '0000-00-00', '', 'Laki-laki', ''),
('1375000005', '', '0000-00-00', '', 'Laki-laki', ''),
('1375111111111', 'Bobi', '2000-04-15', 'Jl.Cempaka No 201', 'Laki-laki', '083666666666'),
('1375222222222', 'Bowo', '1999-04-10', 'Jl.Cemara No 9', 'Laki-laki', '08172177171717'),
('13752909292929', 'Lina', '2000-09-09', 'Jl.Cemara No.12', 'Perempuan', '08366666663'),
('13753200000', 'Son', '2000-04-07', 'Jl.Delima No.21', 'Laki-laki', '0837821321'),
('137532909090', 'Dhinda', '2000-03-02', 'Jl.Cempaka No10', 'Perempuan', '083783291310'),
('13829082390', 'Lolo', '2020-04-17', 'Jl.Cempaka No.21', 'Laki-laki', '081278947389'),
('14', 'Ujang', '1976-04-01', 'jl hang tuah no 110, RT04/RW04, kec. Siak Hulu ', 'Laki-laki', '0812343434'),
('14001', 'Susi Susanti', '1994-04-14', 'Jl Pasir Putih no 100, RT02/RW01 gg. Amalia', 'Perempuan', '08521813738'),
('14002', 'Ilham Saputra', '1990-07-23', 'Jl Paus no 29, Nangka', 'Laki-laki', '0813234235'),
('14003', 'Ismail bin Mail', '2000-09-23', 'Jl. Durian Runtuh RT01/RW01 , dekat pasar', 'Laki-laki', '08231237738'),
('1401061000008', 'nedi', '2000-01-10', 'jl anggur', 'Perempuan', '123456678'),
('15000002', 'Susanto', '1977-11-21', 'Komplek Duta Mas, Jl. Sawo no 119', 'Laki-laki', '08112222122'),
('18000025', 'Angela Piter', '2000-07-21', 'Jl Merdeka No 112, RT05/RW02 Pekanbaru KOta', 'Perempuan', '0871666222'),
('18200001', 'Fikri Maulana', '1999-08-18', 'Harapan Raya no 20', 'Laki-laki', '081117726123'),
('19', 'Aji', '2020-03-05', 'pdg', 'Laki-laki', '9090'),
('21', 'Jono', '1975-03-02', 'jl Kereta api , no 09, RT01/RW03 , Pekanbaru Kota', 'Laki-laki', '0831234344'),
('3334222', 'fulan', '1999-12-12', 'ntynjr', 'Laki-laki', '345346'),
('34334534', 'hrth', '2020-04-27', 'hfh', 'Laki-laki', '54643656'),
('4', 'lon', '0000-00-00', '', 'Laki-laki', ''),
('4232213141', 'haji muhidin', '1966-02-10', 'fnjksrngf', 'Laki-laki', '4732984'),
('4322222', 'gbrf', '1997-11-18', 'hy5r', 'Laki-laki', '5345'),
('45898475', 'njvfdkbgj', '2020-12-10', 'fer,m m', 'Laki-laki', '0931793'),
('565565656', 'dcjifoe', '2000-12-10', 'nyjny', 'Laki-laki', '456454664'),
('64', '', '0000-00-00', '', 'Laki-laki', ''),
('641', '', '0000-00-00', '', 'Laki-laki', ''),
('66666665555', 'kipli', '1994-03-15', 'gdfggg', 'Laki-laki', '4523'),
('77777', 'gtytyht', '2019-09-11', 'htynt', 'Laki-laki', '564456'),
('78', 'llii', '2020-03-17', 'pdg', 'Perempuan', 'qwqwq'),
('789078', '1111111', '2020-04-01', 'Jl.Meriam No.34', 'Laki-laki', '08377777777'),
('89', 'son', '2020-03-25', 'pdg', 'Laki-laki', '08467567'),
('90', 'lala', '2000-03-18', 'pdg', 'Perempuan', '08267831728'),
('9786865', 'hvug', '2135-03-10', 'wrg', 'Laki-laki', '081220226859'),
('fwerg', 'ndiewu', '1011-10-10', 'fheuiw3`', 'Laki-laki', '348279');

-- --------------------------------------------------------

--
-- Struktur dari tabel `petugaskepolisian`
--

CREATE TABLE `petugaskepolisian` (
  `nrp` varchar(20) NOT NULL,
  `nama` varchar(39) NOT NULL,
  `jabatan` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `petugaskepolisian`
--

INSERT INTO `petugaskepolisian` (`nrp`, `nama`, `jabatan`) VALUES
('', '', 'Please Select'),
('8000094', 'Lin', 'Penyidik pembantu'),
('80083192', 'Joni', 'Penyelidik'),
('80989089', 'rui', 'Penyidik pembantu'),
('8888888888', 'Lim', 'Penyelidik'),
('9999999', 'Bao', 'Penyelidik');

-- --------------------------------------------------------

--
-- Struktur dari tabel `status_penduduk`
--

CREATE TABLE `status_penduduk` (
  `id_status` varchar(20) NOT NULL,
  `status_dlmlap` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `status_penduduk`
--

INSERT INTO `status_penduduk` (`id_status`, `status_dlmlap`) VALUES
('S01', 'Pelapor'),
('S02', 'Terlapor'),
('S03', 'Saksi'),
('S04', 'Pelaku');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indeks untuk tabel `detailpenduduk`
--
ALTER TABLE `detailpenduduk`
  ADD UNIQUE KEY `id_detailpddk` (`nik`,`no_lapkejadian`),
  ADD KEY `no_lapkejadian` (`no_lapkejadian`) USING BTREE,
  ADD KEY `nik` (`nik`) USING BTREE;

--
-- Indeks untuk tabel `detailstatus`
--
ALTER TABLE `detailstatus`
  ADD PRIMARY KEY (`id_detail`);

--
-- Indeks untuk tabel `detail_admin`
--
ALTER TABLE `detail_admin`
  ADD UNIQUE KEY `id_detailadmin` (`id`,`no_lapkejadian`);

--
-- Indeks untuk tabel `detail_kejahatan`
--
ALTER TABLE `detail_kejahatan`
  ADD UNIQUE KEY `id_kejahatan` (`id_kejahatan`,`no_lapkejadian`),
  ADD KEY `no_lapkejadian` (`no_lapkejadian`);

--
-- Indeks untuk tabel `detail_pasal`
--
ALTER TABLE `detail_pasal`
  ADD UNIQUE KEY `id_pasal` (`id_pasal`,`id_kejahatan`),
  ADD KEY `detail_pasal_ibfk_2` (`id_kejahatan`);

--
-- Indeks untuk tabel `detail_penyidik`
--
ALTER TABLE `detail_penyidik`
  ADD UNIQUE KEY `nrp` (`nrp`,`no_lapkejadian`),
  ADD KEY `no_lapkejadian` (`no_lapkejadian`);

--
-- Indeks untuk tabel `jenis_kejahatan`
--
ALTER TABLE `jenis_kejahatan`
  ADD PRIMARY KEY (`id_jeniskejahatan`);

--
-- Indeks untuk tabel `kecamatan`
--
ALTER TABLE `kecamatan`
  ADD PRIMARY KEY (`id_kecamatan`);

--
-- Indeks untuk tabel `kejahatan`
--
ALTER TABLE `kejahatan`
  ADD PRIMARY KEY (`id_kejahatan`),
  ADD KEY `id_jeniskejahatan_2` (`id_jeniskejahatan`);

--
-- Indeks untuk tabel `laporan`
--
ALTER TABLE `laporan`
  ADD PRIMARY KEY (`no_lapkejadian`),
  ADD KEY `id_kecamatan` (`id_kecamatan`);

--
-- Indeks untuk tabel `pasal`
--
ALTER TABLE `pasal`
  ADD PRIMARY KEY (`id_pasal`);

--
-- Indeks untuk tabel `penduduk`
--
ALTER TABLE `penduduk`
  ADD PRIMARY KEY (`nik`);

--
-- Indeks untuk tabel `petugaskepolisian`
--
ALTER TABLE `petugaskepolisian`
  ADD PRIMARY KEY (`nrp`);

--
-- Indeks untuk tabel `status_penduduk`
--
ALTER TABLE `status_penduduk`
  ADD PRIMARY KEY (`id_status`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `detailstatus`
--
ALTER TABLE `detailstatus`
  MODIFY `id_detail` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `detailpenduduk`
--
ALTER TABLE `detailpenduduk`
  ADD CONSTRAINT `detailpenduduk_ibfk_1` FOREIGN KEY (`nik`) REFERENCES `penduduk` (`nik`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `detailpenduduk_ibfk_2` FOREIGN KEY (`no_lapkejadian`) REFERENCES `laporan` (`no_lapkejadian`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `detail_kejahatan`
--
ALTER TABLE `detail_kejahatan`
  ADD CONSTRAINT `detail_kejahatan_ibfk_1` FOREIGN KEY (`no_lapkejadian`) REFERENCES `laporan` (`no_lapkejadian`),
  ADD CONSTRAINT `detail_kejahatan_ibfk_2` FOREIGN KEY (`id_kejahatan`) REFERENCES `kejahatan` (`id_kejahatan`);

--
-- Ketidakleluasaan untuk tabel `detail_pasal`
--
ALTER TABLE `detail_pasal`
  ADD CONSTRAINT `detail_pasal_ibfk_1` FOREIGN KEY (`id_pasal`) REFERENCES `pasal` (`id_pasal`),
  ADD CONSTRAINT `detail_pasal_ibfk_2` FOREIGN KEY (`id_kejahatan`) REFERENCES `kejahatan` (`id_kejahatan`);

--
-- Ketidakleluasaan untuk tabel `detail_penyidik`
--
ALTER TABLE `detail_penyidik`
  ADD CONSTRAINT `detail_penyidik_ibfk_1` FOREIGN KEY (`no_lapkejadian`) REFERENCES `laporan` (`no_lapkejadian`),
  ADD CONSTRAINT `detail_penyidik_ibfk_2` FOREIGN KEY (`nrp`) REFERENCES `petugaskepolisian` (`nrp`);

--
-- Ketidakleluasaan untuk tabel `kejahatan`
--
ALTER TABLE `kejahatan`
  ADD CONSTRAINT `kejahatan_ibfk_1` FOREIGN KEY (`id_jeniskejahatan`) REFERENCES `jenis_kejahatan` (`id_jeniskejahatan`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
