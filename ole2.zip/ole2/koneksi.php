<?php 
$host ="localhost";
$username ="root";
$password = "";
$database = "dbkepolisian";
$conn = mysqli_connect($host,$username,$password,$database);

 // if($conn){
	//  	echo "<h1>Sukses</h1>";
	//  }else{
	//  	echo "<h1>Gagal</h1>";
	// }

 ?>

